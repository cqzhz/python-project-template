class Tool2:
    def foo2(self):
        print("helloworld2")