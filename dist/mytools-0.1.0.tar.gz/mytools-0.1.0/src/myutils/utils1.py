class Utils1:
    def bar1(self):
        print("helloutils1")