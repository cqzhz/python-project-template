class Utils2:
    def bar2(self):
        print("helloutils2")