class Tool1:
    def foo1(self):
        print("helloworld1")